# File Type Challenge — Answer Key

Run `python file_identifier.py <file>` on each file to find out which are
disguised. Below is the solution.

## REAL files (extension matches the actual content)
1. photo_real.png     -> really a PNG image      ✅ REAL
2. document_real.pdf  -> really a PDF document    ✅ REAL
3. notes_real.txt     -> really plain text        ✅ REAL

## FAKE files (extension is a lie — the tool should warn)
4. sunset.jpg  -> actually a Python script (#! shebang)   ❌ FAKE
5. logo.png    -> actually a Bash shell script           ❌ FAKE
6. backup.zip  -> actually a PDF document                ❌ FAKE
7. report.docx -> actually a PNG image                   ❌ FAKE
8. song.mp3    -> actually a GIF image                   ❌ FAKE

## Scoreboard
- 3 real files
- 5 disguised files

Tip for players: trust the bytes, not the name.
